const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Mongoose connection
mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB connection error:', err));

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Multer config for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.join(__dirname, 'uploads'));
  },
  filename: function (req, file, cb) {
    const uniqueName = `${Date.now()}-${file.originalname}`;
    cb(null, uniqueName);
  },
});
const upload = multer({ storage: storage });

// Mongoose Schema
const reviewSchema = new mongoose.Schema({
  name: { type: String, required: true },
  comment: { type: String, required: true },
  rating: { type: Number, required: true },
  imagePath: { type: String },
}, { timestamps: true });

const Review = mongoose.model('Review', reviewSchema);

// Routes
app.get('/reviews', async (req, res) => {
  try {
    const reviews = await Review.find().exec();
    res.json(reviews);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch reviews.' });
  }
});

app.post('/reviews', upload.single('image'), async (req, res) => {
  try {
    const { name, comment, rating } = req.body;
    const imagePath = req.file ? req.file.filename : null;

    const newReview = new Review({
      name,
      comment,
      rating: Number(rating),
      imagePath,
    });

    await newReview.save();
    res.status(201).json({ message: 'Review saved!', review: newReview });
  } catch (error) {
    res.status(500).json({ error: 'Failed to save review.' });
  }
});

// Serve static files from the root directory
app.use(express.static(path.join(__dirname, '../dist'))); // Serve React's dist folder

// Catch-All Route for React// server.js
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../dist', 'index.html'));
  });

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server is running on http://localhost:${PORT}`);
});