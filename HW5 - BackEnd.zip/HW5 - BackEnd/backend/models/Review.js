// /backend/models/Review.js

const mongoose = require('mongoose');

// Define the schema for a review
const reviewSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },
    comment: {
      type: String,
      required: true,
      trim: true
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5
    },
    imagePath: {
      type: String, // filename stored in /uploads
      default: null
    }
  },
  {
    timestamps: true // automatically adds createdAt and updatedAt fields
  }
);

// Export the model to use in server.js
module.exports = mongoose.model('Review', reviewSchema);
