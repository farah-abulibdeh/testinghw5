import { useState, useEffect } from 'react';
import Footer from './Footer';
import Navbar from './Navbar';
import '../index.css';

export default function Reviews() {
  useEffect(() => {
    document.body.classList.add('review');
    return () => document.body.classList.remove('review');
  }, []);

  const [name, setName] = useState('');
  const [comment, setComment] = useState('');
  const [rating, setRating] = useState(0);
  const [imageFile, setImageFile] = useState(null);
  const [reviews, setReviews] = useState([]);

  const API_URL = 'http://localhost:3000'; // Change this if you deploy your backend

 
  useEffect(() => {
    async function fetchReviews() {
      try {
        const response = await fetch(`${API_URL}/reviews`);
        const data = await response.json();
        setReviews(data);
      } catch (error) {
        console.error('Failed to fetch reviews:', error);
      }
    }

    fetchReviews();
  }, []);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file && file.type.includes('image')) {
      setImageFile(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const formData = new FormData();
      formData.append('name', name);
      formData.append('comment', comment);
      formData.append('rating', rating);
      if (imageFile) {
        formData.append('image', imageFile);
      }

      const response = await fetch(`${API_URL}/reviews`, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      if (response.ok) {
        setReviews([...reviews, data.review]);
        setName('');
        setComment('');
        setRating(0);
        setImageFile(null);
      } else {
        console.error('Error saving review:', data.error);
      }
    } catch (error) {
      console.error('Error submitting review:', error);
    }
  };

  return (
    <>
      <div className="review">
        <Navbar />
        <main className="review">
          <section>
            <h2>Leave a Review</h2>
            <form id="review-form" onSubmit={handleSubmit}>
              <label>Name:</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />

              <label>Rating:</label>
              <div id="rating">
                {[1, 2, 3, 4, 5].map((star) => (
                  <span
                    key={star}
                    onClick={() => setRating(star)}
                    style={{ cursor: 'pointer', fontSize: '2rem' }}
                  >
                    {rating >= star ? '⭐' : '☆'}
                  </span>
                ))}
              </div>

              <label>Comment:</label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                required
              ></textarea>

              <label>Upload Image:</label>
              <input
                type="file"
                accept="image/jpeg, image/png"
                onChange={handleImageChange}
              />

              {imageFile && (
                <div id="thumbnail">
                  <p>{imageFile.name}</p>
                  <button
                    type="button"
                    className="delete-btn"
                    onClick={() => setImageFile(null)}
                  >
                    Delete
                  </button>
                </div>
              )}

              <button type="submit">Submit Your Review</button>
            </form>
          </section>

          <section>
            <h2>Customer Reviews</h2>
            <div id="reviews-container">
              {reviews.map((rev, index) => (
                <div key={index} className="review-box">
                  <h3>{rev.name}</h3>
                  <p>{rev.comment}</p>
                  <p>Rating: {'⭐'.repeat(rev.rating)}</p>
                  {rev.imagePath && (
                    <img
                      src={`${API_URL}/uploads/${rev.imagePath}`}
                      alt="review"
                      className="review-image"
                    />
                  )}
                </div>
              ))}
            </div>
          </section>
        </main>
        <Footer />
      </div>
    </>
  );
}
