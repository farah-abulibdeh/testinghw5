import React, { useEffect, useState } from "react";
import Footer from './Footer';
import Navbar from './Navbar';
import '../index.css';
import cinaFamilyImage from '../assets/cina-family.png';
import victoryAudio from '../assets/victory-an-eternal-win.mp3';
import weejamoroll from '../assets/weejamoroll.png';
import mochaImg from '../assets/mocha.jpg';
import espressoImg from '../assets/espresso.jpg';
import cappuccinoImg from '../assets/cappucinno.jpg';


export default function Home() {

  useEffect(() => {
    document.body.classList.add('home');
    return () => document.body.classList.remove('home');
  }, []);

  const [apiMenu, setApiMenu] = useState([]);
  const [detailsVisible, setDetailsVisible] = useState({});

  useEffect(() => {
    async function fetchMenu() {
      try {
        let response = await fetch('https://la-restaurants-menu.p.rapidapi.com/menus', {
          method: 'GET',
          headers: {
            'x-rapidapi-key': '937bd436a0msh18bb3e3ec314719p1987e2jsn662006132487',
            'x-rapidapi-host': 'la-restaurants-menu.p.rapidapi.com'
          }
        });
        let data = await response.json();
        setApiMenu(data);
        console.log('API menu fetched:', data);
      } catch (error) {
        console.error(error);
      }
    }
    fetchMenu();
  }, []);

  const toggleDetails = (itemName) => {
    setDetailsVisible((prev) => ({
      ...prev,
      [itemName]: !prev[itemName],
    }));
  };

  const specialsMenu = [
    {
      category: "Breakfast",
      items: [
        { name: "Eggs & Bacon", details: "Scrambled or sunny-side-up eggs, bacon, and toast." },
        { name: "Cinnamon Rolls", details: "Sweet baked dough filled with cinnamon-sugar filling.", image: weejamoroll, imgAlt: "Cinnamoroll", imgHeight: "20px" },
        { name: "Pancakes", details: "Our signature buttermilk pancake with homemade maple syrup." },
        { name: "Blueberry Muffin", details: "385 calories of berry deliciousness." },
        { name: "English Breakfast", details: "Fried eggs, sausages, bacon, baked beans, grilled tomatoes, and mushrooms." },
      ],
    },
    {
      category: "Lunch",
      items: [
        { name: "Grilled Cheese Sandwich", details: "Melted cheese sandwich served with tomato soup." },
        { name: "Caesar Salad", details: "Crisp romaine, parmesan cheese, croutons, and Caesar dressing." },
        { name: "Sweet Potato Soup", details: "Warm, creamy soup with roasted sweet potatoes." },
        { name: "Macaroni & Cheese", details: "Cheesy, creamy classic comfort food." },
        { name: "Burrito Bowl", details: "Rice, beans, veggies, and protein in a bowl." },
      ],
    },
    {
      category: "Dinner",
      items: [
        { name: "Steak Fries", details: "Juicy steak served with crispy fries." },
        { name: "Herb Roasted Chicken", details: "Roasted chicken with fresh herbs and garlic." },
        { name: "Grilled Salmon", details: "Grilled salmon fillet with lemon butter sauce." },
        { name: "Vegetarian Pasta", details: "Pasta tossed with seasonal vegetables." },
        { name: "Garden Salad", details: "Mixed greens with fresh veggies and vinaigrette." },
      ],
    },
    {
      category: "Desserts",
      items: [
        { name: "Chocolate Lava Cake", details: "Warm chocolate cake with molten center." },
        { name: "Tiramisu", details: "Classic Italian dessert with espresso and mascarpone." },
        { name: "Cheesecake", details: "Rich, creamy cheesecake with berry topping." },
      ],
    },
    {
      category: "Drinks",
      items: [
        { name: "Macchiato", details: "Espresso with a dollop of foamed milk.", image: mochaImg, link: "https://hellokitty.fandom.com/wiki/Mocha", imgAlt: "Mocha", imgHeight: "50px" },
        { name: "Espresso", details: "Strong, rich espresso shot.", image: espressoImg, link: "https://hellokitty.fandom.com/wiki/Espresso", imgAlt: "Espresso", imgHeight: "30px" },
        { name: "Cappuccino", details: "Espresso with steamed milk and foam.", image: cappuccinoImg, link: "https://hellokitty.fandom.com/wiki/Cappuccino", imgAlt: "Cappuccino", imgHeight: "30px" },
        { name: "Hot Chocolate", details: "Creamy hot chocolate with whipped cream." },
      ],
    },
  ];


  return (
    <>
      <div className="home">
        <header className="home-header">
          <h1>Welcome to Crumb Cabin!</h1>
        </header>

        <Navbar />
        <main>
          <section id="updates">
            <h2>Updates</h2>
            <article>
              We're thrilled to announce an exclusive collaboration between Crumb Cabin and Cinnamoroll Family! Enjoy magical treats like fresh Cinnamon Rolls, Macchiatos by Mocha, and robust Espresso.
            </article>

            <aside>
              <a href="https://hellokitty.fandom.com/wiki/Cinnamoroll">
                <img src={cinaFamilyImage} alt="Cinnamoroll Image" />
              </a>
            </aside>

            <audio src={victoryAudio} controls autoPlay>
              <p>This browser does not support our audio format.</p>
            </audio>

          </section>

          <section>
            <h2>Main Menu (API)</h2>
            <div>
            
              {apiMenu.map((item, index) => (
                <div key={index} className="menu-item">
                  <h3 onClick={() => toggleDetails(item.menuItem)}>{item.menuItem}</h3>
                  {detailsVisible[item.menuItem] && <p>Source: {item.source}</p>}
                </div>
              ))}
            </div>
          </section>

          <section id="menu">
            <h2>Today's Specials</h2>
            {specialsMenu.map((section, idx) => (
              <div key={idx}>
                <h4>{section.category}</h4>
                <ul>
                  {section.items.map((item, index) => (
                    <li key={index} className="menu-item" onClick={() => toggleDetails(item.name)}>
                      {item.name}
                      {item.link && item.image && (
                        <a href={item.link} target="_blank" rel="noopener noreferrer">
                          <img src={item.image} alt={item.imgAlt} height={item.imgHeight} />
                        </a>
                      )}
                      {item.image && !item.link && (
                        <img src={item.image} alt={item.imgAlt} height={item.imgHeight} />
                      )}
                      {detailsVisible[item.name] && <p className="details">{item.details}</p>}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </section>


        </main>

        <Footer />
      </div>
    </>
  );
}