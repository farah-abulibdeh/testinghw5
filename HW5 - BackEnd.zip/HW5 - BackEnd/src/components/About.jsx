import React, { useEffect } from 'react';
import Footer from './Footer';
import Navbar from './Navbar';
import '../index.css';
import BeeImg from '../assets/Bee.png';
import PuppyCatImg from '../assets/PuppyCat.png';
import DeckardImg from '../assets/Deckard.png';
import MerlinImg from '../assets/Merlin.png';

const About = () => {
  useEffect(() => {
    document.body.classList.add('about');
    return () => document.body.classList.remove('about');
  }, []);

  return (
    <div className="about">
      <Navbar />
      <main>
        <section>
          <h2>About!</h2>
          <p>
            Welcome to Crumb Cabin, where rustic charm meets modern flavor! Nestled in a serene setting,
            our café and restaurant is dedicated to providing an inviting atmosphere paired with a diverse
            menu crafted with passion and creativity.
          </p>
        </section>

        <section>
          <h2>Meet the Team</h2>
          <ul>
            <li>
              <img src={DeckardImg} alt="Deckard" height="80px" />
              <p>Deckard <br/> Our Talented Chef! <br/>
              <em><h6>just don't tell him to bake anything</h6> </em> </p>
            </li>
            <li>
              <img src={BeeImg} alt="Bee" height="80px" />
              <p>Bee <br/> Head Barista & Lovely Waitress</p>
            </li>
            <li>
              <img src={PuppyCatImg} alt="PuppyCat" height="80px" />
              <p>PuppyCat <br/> Dessert Supervisor</p>
            </li>
            <li>
              <img src={MerlinImg} alt="Merlin" height="80px" />
              <p>Merlin<br/> Our Techy Wizard</p>
            </li>
          </ul>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default About;