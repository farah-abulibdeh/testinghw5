import { Link } from "react-router-dom";
import '../index.css';

export default function Navbar() {
  return (
    <div className="navbar-wrapper">
      <nav className="main-nav">
        <div className="nav-drop">
          <Link to="/">Home</Link>
          <span>You're already home!</span>
        </div>
        <div className="nav-drop">
          <Link to="/about">About</Link>
          <span>Learn more about us!</span>
        </div>
        <div className="nav-drop">
          <Link to="/reviews">Reviews</Link>
          <span>See what people think!</span>
        </div>
      </nav>
    </div>
  );
}
