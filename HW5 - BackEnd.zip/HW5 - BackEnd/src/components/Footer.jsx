
export default function Footer() {
  return (
    <footer>
      <p>All images belong to Sanrio ©. Audio is owned by Capcom ©.</p>
    </footer>
  )
}
