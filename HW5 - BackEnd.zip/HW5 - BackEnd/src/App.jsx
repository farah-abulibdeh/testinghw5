import { Routes, Route, Navigate } from 'react-router-dom';
import Home from './components/Home';
import Reviews from './components/Reviews';
import About from './components/About';
import './index.css';

export default function App() {

  return (
    <div className="app-container">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/reviews" element={<Reviews />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </div>
  );
}
